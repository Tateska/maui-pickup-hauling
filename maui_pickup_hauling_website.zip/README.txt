MAUI PICKUP & HAULING WEBSITE

Files:
- index.html: your responsive one-page website. Open it in a browser to preview it.

The website includes:
- Business name: Maui Pickup & Hauling
- Phone: 808-868-1224
- Email: erelissounds@gmail.com
- Services: dump runs, green waste, furniture/appliance pickups, Marketplace pickups, deliveries, small moves
- Service area: all Maui, subject to job/location quote
- Starting price: $75, with pricing disclaimer

To publish it for free:
1. Use a free static website host such as GitHub Pages (requires a free GitHub account), or use Google Sites and recreate the design there.
2. For GitHub Pages, create a new public repository, upload index.html, then enable Pages in the repository's Settings.
3. A free host provides a hosted URL, but getting to the top of Google is not guaranteed and can take time.
4. Before publishing, confirm the business name is available and review all wording/prices/service coverage.

Note: this is a website file, not yet published online. No domain or hosting account has been purchased.
